//
//  Continente.m
//  ParseJson
//
//  Created by Isaac Velazquez on 07/09/12.
//  Copyright (c) 2012 EL UNIVERSAL. All rights reserved.
//

#import "Continente.h"

@implementation Continente

@synthesize StrID;
@synthesize StrName;

@end
