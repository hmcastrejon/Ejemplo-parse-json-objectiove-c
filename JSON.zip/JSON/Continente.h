//
//  Continente.h
//  ParseJson
//
//  Created by Isaac Velazquez on 07/09/12.
//  Copyright (c) 2012 EL UNIVERSAL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Continente : NSObject

@property (nonatomic ,retain) NSString *StrID;
@property (nonatomic ,retain) NSString *StrName;

@end
